int a;
int b[10];

void foo () {
  a = 2; 
  b[a] = a;
}
