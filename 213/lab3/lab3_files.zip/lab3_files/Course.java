
public class Course {
	public String name;
	public int mark;
	
	public Course(String n, int m){
		name = n;
		mark = m;
	}
}
