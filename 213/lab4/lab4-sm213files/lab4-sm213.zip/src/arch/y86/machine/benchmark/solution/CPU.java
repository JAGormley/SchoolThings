package arch.y86.machine.benchmark.solution;

import machine.AbstractMainMemory;
import machine.Register;
import machine.RegisterSet;
import arch.y86.machine.AbstractY86CPU;

public class CPU extends AbstractY86CPU.Sequential {
    
    public CPU (String name, AbstractMainMemory memory) {
        super (name, memory);
    }
    
    @Override protected void cycle () throws InvalidInstructionException, MachineHaltException, AbstractMainMemory.InvalidAddressException, Register.TimingException, ImplementationException {
        cycleSeq ();
    }
    
    private boolean isCondCodeMatch (int iFn) throws InvalidInstructionException {
        boolean cnd;
        boolean zf = (P.cc.get () & 0x100) != 0;
        boolean sf = (P.cc.get () & 0x010) != 0;
        boolean of = (P.cc.get () & 0x001) != 0;
        switch (iFn) {
            case C_NC:
                cnd = true;
                break;
            case C_LE:
                cnd = (sf ^ of) | zf;
                break;
            case C_L:
                cnd = sf ^ of;
                break;
            case C_E:
                cnd = zf;
                break;
            case C_NE:
                cnd = ! zf;
                break;
            case C_GE:
                cnd = ! (sf ^ of);
                break;
            case C_G:
                cnd = ! (sf ^ of) & ! zf;
                break;
            default:
                throw new InvalidInstructionException ();
        }
        return cnd;
    }
    
    private int aluCompute (int aluFn, int aluA, int aluB) throws InvalidInstructionException {
        int result;
        boolean overflow;
        switch (aluFn) {
            case A_ADDL:
                result = aluB + aluA;
                overflow = ((aluB < 0) == (aluA < 0)) && ((result < 0) != (aluB < 0));
                break;
            case A_SUBL:
                result = aluB - aluA;
                overflow = ((aluB < 0) != (aluA < 0)) && ((result < 0) != (aluB < 0));
                break;
            case A_ANDL:
                result = aluB & aluA;
                overflow = false;
                break;
            case A_XORL:
                result = aluB ^ aluA;
                overflow = false;
                break;
            default:
                throw new InvalidInstructionException ();
        }
        p.cc.set ((result==0? 0x100: 0x000) | (result<0? 0x10: 0x00) | (overflow? 0x1: 0x0));
        return result;
    }
    
    @Override protected void writeBack () throws MachineHaltException, InvalidInstructionException, AbstractMainMemory.InvalidAddressException {
        int pc  = F.pc.get();
        int iCd = (int) mem.read (pc,1)[0].value () >>> 4;
        int iFn = (int) mem.read (pc,1)[0].value () & 0xf;
        int rA=0, rB=0;
        if (iCd!=I_HALT && iCd!=I_NOP && iCd!=I_RET && iCd!=I_LEAVE) {
            rA  = (int) mem.read (pc+1,1)[0].value () >>>4;
            rB  = (int) mem.read (pc+1,1)[0].value () & 0xf;
        }
        int valC=0, valP=0;
        if (iCd==I_IRMOVL || iCd==I_RMMOVL || iCd==I_MRMOVL || iCd==I_IOPL || iCd==I_JMPI) {
            valP = pc+6;
            valC = mem.readIntegerUnaligned (pc+2);
        } else if (iCd==I_JXX || iCd==I_CALL || iCd==I_LEAVE) {
            valP = pc+5;
            valC = mem.readIntegerUnaligned (pc+1);
        } else if (iCd==I_NOP)
            valP = pc+1;
        else
            valP = pc+2;
        try {
            switch (iCd) {
                case I_HALT:
                    if (iFn!=0)
                        throw new InvalidInstructionException ();
                    throw new MachineHaltException ();
                case I_NOP:
                    if (iFn!=0)
                        throw new InvalidInstructionException ();
                    break;
                case I_IRMOVL:
                    if (iFn!=0 || rA!=0xf)
                        throw new InvalidInstructionException ();
                    reg.set (rB, valC);
                    break;
                case I_RMMOVL:
                    if (iFn!=0)
                        throw new InvalidInstructionException ();
                    mem.writeInteger (reg.get (rB)+valC, reg.get (rA));
                    break;
                case I_MRMOVL:
                    if (iFn!=0)
                        throw new InvalidInstructionException ();
                    reg.set (rA, mem.readInteger (reg.get(rB)+valC));
                    break;
                case I_RET:
                    if (iFn!=0)
                        throw new InvalidInstructionException ();
                    valP = mem.readInteger (reg.get (R_ESP));
                    reg.set (R_ESP, reg.get (R_ESP)+4);
                    break;
                case I_PUSHL:
                    if (iFn!=0)
                        throw new InvalidInstructionException ();
                    mem.writeInteger (reg.get (R_ESP)-4, reg.get (rA));
                    reg.set (R_ESP, reg.get (R_ESP)-4);
                    break;
                case I_POPL:
                    if (iFn!=0)
                        throw new InvalidInstructionException ();
                    reg.set (rA, mem.readInteger (reg.get (R_ESP)));
                    reg.set (R_ESP, reg.get (R_ESP)+4);
                    break;
                case I_LEAVE:
                    if (iFn!=0)
                        throw new InvalidInstructionException ();
                    reg.set (R_ESP, reg.get (R_EBP)+4);
                    reg.set (R_EBP, mem.readInteger (reg.get (R_EBP)));
                    break;
                case I_RRMVXX:
                    if (isCondCodeMatch (iFn))
                        reg.set (rB, reg.get (rA));
                    break;
                case I_JXX:
                    if (isCondCodeMatch (iFn))
                        valP = valC;
                    break;
                case I_OPL:
                    reg.set (rB, aluCompute (iFn, reg.get (rA), reg.get (rB)));
                    break;
                case I_IOPL:
                    reg.set (rB, aluCompute (iFn, valC, reg.get (rB)));
                    break;
                case I_CALL:
                    if (iFn == X_DIRECT_CALL)
                    {
                        valP = valC;
                    }
                    else if (iFn == X_INDIRECT_CALL)
                    {
                        mem.writeInteger (reg.get (R_ESP)-4, valP);
                        valP = reg.get(rB);
                    }
                    else if ((iFn & X_INDIRECT_MASK) == X_INDIRECT_FLAG)
                    {
                        reg.set(rA, valP);
                        valP = (iFn & X_SCALE_MASK) * reg.get (rB) + valC;
                    }
                    else
                    {
                        reg.set(rA, valP);
                        valP = (iFn & X_SCALE_MASK) * mem.readInteger(valC + reg.get(rB));
                    }
                    break;
                case I_JMPI:
                    switch (iFn & X_INDIRECT_MASK)
                {
                    case X_INDIRECT_FLAG:
                        valP = (iFn & X_SCALE_MASK) * reg.get (rB) + valC;
                        break;
                    case X_DBL_INDIRECT_FLAG:
                        valP = mem.readInteger ((iFn & X_SCALE_MASK) * reg.get (rB) + valC);
                        break;
                    default:
                }
                    break;
                default:
                    throw new InvalidInstructionException ();
            }
        } catch (RegisterSet.InvalidRegisterNumberException e) {
            throw new InvalidInstructionException ();
        }
        w.pc.set (valP);
    }
    
    @Override protected void fetch   () {;}
    @Override protected void decode  () {;}
    @Override protected void execute () {;}
    @Override protected void memory  () {;}
}