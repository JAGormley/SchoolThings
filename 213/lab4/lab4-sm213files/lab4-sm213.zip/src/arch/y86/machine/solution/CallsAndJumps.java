package arch.y86.machine.solution;

import arch.y86.machine.AbstractY86CPU;
/**
 * This class contains a number of simple static functions that will be useful when dealing with
 * our improved "call" and "jmp" instructions. All four solution CPU classes will make use of them.
 * 
 * @author patrice
 */
public class CallsAndJumps
{
  /**
   * Determine if we have an indirect jump
   * 
   *  @param iCd opcode
   *  @param iFn function
   */
  public static boolean isIndirectJmp(int iCd, int iFn)
  {
    return iCd == AbstractY86CPU.I_JMPI && (iFn & AbstractY86CPU.X_INDIRECT_MASK) == AbstractY86CPU.X_INDIRECT_FLAG;
  }

  /**
   * Determine if we have an indirect call that puts the return address in a register.
   * 
   * @param iFn function
   */
  public static boolean isCallUsingReg(int iFn)
  {
    return (iFn & AbstractY86CPU.X_SCALE_MASK) != 0;
  }

  /**
   * Determine if we have an indirect call that puts the return address in a register.
   * 
   * @param iFn function
   */
  public static boolean isDirectCall(int iFn)
  {
    return iFn == AbstractY86CPU.X_DIRECT_CALL;
  }

  /**
   * Determine if we have an indirect call that puts the return address in a register.
   * 
   *  @param iCd opcode
   * @param iFn function
   */
  public static boolean isCallUsingReg(int iCd, int iFn)
  {
    return iCd == AbstractY86CPU.I_CALL && isCallUsingReg(iFn);
  }

  /**
   * Determine if we have an indirect call of the form "call (rA)"
   * 
   *  @param iFn function
   */
  public static boolean isIndirectCallUsingStack(int iFn)
  {
    return iFn == AbstractY86CPU.X_INDIRECT_CALL;
  }

  /**
   * Determine if we have an indirect call of the form "call (rA)"
   * 
   *  @param iCd opcode
   *  @param iFn function
   */
  public static boolean isIndirectCallUsingStack(int iCd, int iFn)
  {
    return iCd == AbstractY86CPU.I_CALL && iFn == AbstractY86CPU.X_INDIRECT_CALL;
  }

  /**
   * Determine if we have an indirect call of the form "call D(rB), rA"
   * 
   *  @param iFn function
   */
  public static boolean isIndirectCallUsingReg(int iFn)
  {
    return (iFn & AbstractY86CPU.X_INDIRECT_MASK) == AbstractY86CPU.X_INDIRECT_FLAG && (iFn & AbstractY86CPU.X_SCALE_MASK) != 0;
  }

  /**
   * Determine if we have an indirect call of the form "call D(rB), rA"
   * 
   *  @param iCd opcode
   *  @param iFn function
   */
  public static boolean isIndirectCallUsingReg(int iCd, int iFn)
  {
    return iCd == AbstractY86CPU.I_CALL && isIndirectCallUsingReg(iFn);
  }

  /**
   * Determine if we have a doubly indirect call of the form "call *D(rB), rA"
   * 
   *  @param iFn function
   */
  public static boolean isDoublyIndirect(int iFn)
  {
    return (iFn & AbstractY86CPU.X_INDIRECT_MASK) == AbstractY86CPU.X_DBL_INDIRECT_FLAG && (iFn & AbstractY86CPU.X_SCALE_MASK) != 0;
  }
}
