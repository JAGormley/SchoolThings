package arch.y86.machine.pipe.solution;

import static arch.y86.machine.solution.CallsAndJumps.isCallUsingReg;
import static arch.y86.machine.solution.CallsAndJumps.isDirectCall;
import static arch.y86.machine.solution.CallsAndJumps.isDoublyIndirect;
import static arch.y86.machine.solution.CallsAndJumps.isIndirectCallUsingReg;
import static arch.y86.machine.solution.CallsAndJumps.isIndirectCallUsingStack;
import static arch.y86.machine.solution.CallsAndJumps.isIndirectJmp;
import machine.AbstractMainMemory;
import machine.Register;
import machine.RegisterSet;
import ui.Machine;
import arch.y86.machine.AbstractY86CPU;

/**
 * The Simple Machine CPU.
 *
 * Simulate execution of a single cycle of the Simple Machine Y86-Pipe CPU.
 */

public class CPU extends AbstractY86CPU.Pipelined {
  
  public CPU (String name, AbstractMainMemory memory) {
    super (name, memory);
  }
  
  /**
   * Execute one clock cycle with all stages executing in parallel.
   * @throws InvalidInstructionException                if instruction is invalid (including invalid register number).
   * @throws AbstractMainMemory.InvalidAddressException if instruction attemps an invalid memory access (either instruction or data).
   * @throws MachineHaltException                       if instruction halts the CPU.
   * @throws Register.TimingException
   */
  @Override protected void cycle () throws InvalidInstructionException, AbstractMainMemory.InvalidAddressException, MachineHaltException, Register.TimingException, ImplementationException {
    cyclePipe();
  }
  
  
  /**
   * Pipeline Hazard Control
   */
  
  @Override protected void pipelineHazardControl () throws Register.TimingException {
    
    // Control Hazard: Mispredicted Jump
    if (E.iCd.get()==I_JXX && e.cnd.getValueProduced()==0) {
      D.bubble = true;
      E.bubble = true;
    }
    
    // Data-Hazard: Load-Use
    else if ((d.srcA.getValueProduced()!=R_NONE && d.srcA.getValueProduced()==E.dstM.get()) ||
             (d.srcB.getValueProduced()!=R_NONE && d.srcB.getValueProduced()==E.dstM.get())) {
      F.stall  = true;
      D.stall  = true;
      E.bubble = true;
    }
    
    // Control Hazard: Indirect CALL (one stall)
    else if (isIndirectCallUsingStack(D.iCd.get(), D.iFn.get()))
    {
      F.stall  = true;
      D.bubble = true;
    }
    
    // Control Hazard: Indirect JMP or CALL (will stall if in stage D or E).
    else if (D.iCd.get() == I_JMPI || isCallUsingReg(D.iCd.get(), D.iFn.get()) || E.iCd.get() == I_JMPI || isCallUsingReg(E.iCd.get(), E.iFn.get()))
    {
      F.stall  = true;
      D.bubble = true;
    }
    
    // Control Hazard: RET
    else if (D.iCd.get()==I_RET || E.iCd.get()==I_RET || M.iCd.get()==I_RET) {
      F.stall  = true;
      D.bubble = true;
    }
    
    // Control Hazard: Double-Indirect JMPI or CALL will also stall if in stage M.
    else if ((M.iCd.get() == I_CALL || M.iCd.get() == I_JMPI) && isDoublyIndirect(M.iFn.get()))
    {
      F.stall  = true;
      D.bubble = true;
    }
  }
  
  /**
   * The SelectPC part of the fetch stage
   */
  
  @Override protected void fetch_SelectPC () throws Register.TimingException {
    
    // Indirect CALL in E
    if (isIndirectCallUsingStack(E.iCd.get(), E.iFn.get()))
    {
      f.pc.set (E.valA.get());
    }
    
    // Not-taken conditional branch in M
    else if (M.iCd.get()==I_JXX && M.iFn.get()!=C_NC && M.cnd.get()==0)
    {
      f.pc.set (M.valP.get());
    }
    
    // Indirect JMPI or CALL (with displacement and PC in rA) in M
    else if (isIndirectJmp(M.iCd.get(), M.iFn.get()) || isIndirectCallUsingReg(M.iCd.get(), M.iFn.get()))
    {
      f.pc.set (M.valE.get());
    }
    
    // RET or double-indirect JMPI or CALLI in W
    else if (W.iCd.get() == I_RET || (W.iCd.get() == I_CALL || W.iCd.get() == I_JMPI) && isDoublyIndirect(W.iFn.get()))
    {
      f.pc.set (W.valM.get());
    }
    
    // Otherwise, predicted value is correct
    else
    {
      f.pc.set (F.prPC.get());
    }
  }
  
  /**
   * PC prediction part of FETCH stage.  Predicts PC to fetch in next cycle.
   * Writes the predicted PC into the f.prPC register.
   */
  
  @SuppressWarnings ("fallthrough")
  private void fetch_PredictPC () throws Register.TimingException {
    if (f.stat.getValueProduced()==S_AOK)
      switch (f.iCd.getValueProduced()) {
        case I_JXX:   // Predict jumps are taken
          f.prPC.set (f.valC.getValueProduced());
          break;
        case I_CALL:  // Predict direct calls are taken
          if (f.iFn.getValueProduced() == X_DIRECT_CALL)
          {
            f.prPC.set (f.valC.getValueProduced());
            break;
          }
          // No break here. This is intentional.
        default:
          f.prPC.set (f.valP.getValueProduced());
      }
    else
      f.prPC.set (f.pc.getValueProduced());
  }
  
  /**
   * The FETCH stage of CPU
   * @throws Register.TimingException
   */
  
  @Override protected void fetch () throws Register.TimingException {
    try {
      
      // determine correct PC for this stage
      fetch_SelectPC();
      
      // get iCd and iFn
      f.iCd.set (mem.read (f.pc.getValueProduced(),1)[0].value() >>> 4);
      f.iFn.set (mem.read (f.pc.getValueProduced(),1)[0].value() & 0xf);
      
      // stat MUX
      switch (f.iCd.getValueProduced()) {
        case I_HALT:
        case I_NOP:
        case I_IRMOVL:
        case I_RET:
        case I_PUSHL:
        case I_POPL:
        case I_LEAVE:
          switch (f.iFn.getValueProduced()) {
            case 0x0:
              f.stat.set (S_AOK);
              break;
            default:
              f.stat.set (S_INS);
              break;
          }
          break;
        case I_RMMOVL:
        case I_MRMOVL:
          switch (f.iFn.getValueProduced()) {
            case 0x0:
            case 0x1:
            case 0x2:
            case 0x4:
              f.stat.set (S_AOK);
              break;
            default:
              f.stat.set (S_INS);
              break;
          }
          break;
        case I_RRMVXX:
        case I_JXX:
          switch (f.iFn.getValueProduced()) {
            case C_NC:
            case C_LE:
            case C_L:
            case C_E:
            case C_NE:
            case C_GE:
            case C_G:
              f.stat.set (S_AOK);
              break;
            default:
              f.stat.set (S_INS);
          }
          break;
        case I_OPL:
        case I_IOPL:
          switch (f.iFn.getValueProduced()) {
            case A_ADDL:
            case A_SUBL:
            case A_ANDL:
            case A_XORL:
            case A_MULL:
            case A_DIVL:
            case A_MODL:
              f.stat.set (S_AOK);
              break;
            default:
              f.stat.set (S_INS);
              break;
          }
          break;
        case I_CALL:
        case I_JMPI:
          int iFn = f.iFn.getValueProduced();
          int scale = iFn & X_SCALE_MASK;
          
          f.stat.set ( (scale == 1 || scale == 2 || scale == 4 || f.iCd.getValueProduced() == I_CALL && scale == 0) ? S_AOK : S_INS);
          break;
        default:
          f.stat.set (S_INS);
          break;
      }
      
      if (f.stat.getValueProduced()==S_AOK) {
        
        // rA MUX
        switch (f.iCd.getValueProduced()) {
          case I_HALT:
            f.rA.set   (R_NONE);
            f.stat.set (S_HLT);
            break;
          case I_RRMVXX:
          case I_RMMOVL:
          case I_MRMOVL:
          case I_OPL:
          case I_PUSHL:
          case I_POPL:
            f.rA.set (mem.read (f.pc.getValueProduced()+1,1)[0].value() >>> 4);
            break;
          case I_CALL:
            f.rA.set(f.iFn.getValueProduced() == X_DIRECT_CALL ? R_NONE : mem.read (f.pc.getValueProduced()+1,1)[0].value() >>> 4);
            break;
          default:
            f.rA.set (R_NONE);
        }
        
        // rB MUX
        switch (f.iCd.getValueProduced()) {
          case I_RRMVXX:
          case I_IRMOVL:
          case I_RMMOVL:
          case I_MRMOVL:
          case I_OPL:
          case I_IOPL:
          case I_JMPI:
            f.rB.set (mem.read (f.pc.getValueProduced()+1,1)[0].value() & 0xf);
            break;
          case I_CALL:
            f.rB.set(isCallUsingReg(f.iFn.getValueProduced()) ? (mem.read(f.pc.getValueProduced()+1,1)[0].value() & 0xf) : R_NONE);
            break;
          default:
            f.rB.set (R_NONE);
        }
        
        // valC MUX
        switch (f.iCd.getValueProduced()) {
          case I_JXX:
            f.valC.set (mem.readIntegerUnaligned (f.pc.getValueProduced()+1));
            break;
          case I_IRMOVL:
          case I_RMMOVL:
          case I_MRMOVL:
          case I_IOPL:
          case I_JMPI:
            f.valC.set (mem.readIntegerUnaligned (f.pc.getValueProduced()+2));
            break;
          case I_CALL:
            int currpc = f.pc.getValueProduced();
            f.valC.set (isIndirectCallUsingStack(f.iFn.getValueProduced()) ? 0 : mem.readIntegerUnaligned (currpc + (isDirectCall(f.iFn.getValueProduced()) ? 1 : 2)));
            break;
          default:
            f.valC.set (0);
        }
        
        // valP MUX
        switch (f.iCd.getValueProduced()) {
          case I_NOP:
          case I_HALT:
          case I_RET:
          case I_LEAVE:
            f.valP.set (f.pc.getValueProduced()+1);
            break;
          case I_RRMVXX:
          case I_OPL:
          case I_PUSHL:
          case I_POPL:
            f.valP.set (f.pc.getValueProduced()+2);
            break;
          case I_CALL:
            int pc = f.pc.getValueProduced();
            switch (f.iFn.getValueProduced()) {
              case X_DIRECT_CALL:
                f.valP.set(pc + 5);
                break;
              case X_INDIRECT_CALL:
                f.valP.set(pc + 2);
                break;
              default:
                f.valP.set(pc + 6);
                break;
            }
            break;
          case I_JXX:
            f.valP.set (f.pc.getValueProduced()+5);
            break;
          case I_IRMOVL:
          case I_RMMOVL:
          case I_MRMOVL:
          case I_IOPL:
          case I_JMPI:
            f.valP.set (f.pc.getValueProduced()+6);
            break;
          default:
            throw new AssertionError();
        }
      }
      
    } catch (AbstractMainMemory.InvalidAddressException iae) {
      f.stat.set (S_ADR);
    }
    
    // predict PC for next cycle
    fetch_PredictPC();
  }
  
  /**
   * Determine current value of specified register by employing data fowarding, where necessary.
   * STUDENT CHANGES THIS METHOD TO IMPLEMENT DATA FORWARDING
   * @param  regNum  number of register being read
   * @return value of register
   * @throws Machine.RegisterSet.InvalidRegisterNumberException if register number is invalid
   */
  private int decode_ReadRegisterWithForwarding (int regNum) throws RegisterSet.InvalidRegisterNumberException, Register.TimingException
  {
    if (regNum == R_NONE)
    {
      return 0;
    }
    
    // Forwarding from E to D.
    if (regNum == E.dstE.get() && e.cnd.getValueProduced() == 1)
    {
      return e.valE.getValueProduced();
    }
    
    // Forwarding from M to D.
    if (regNum == M.dstM.get())
    {
      return m.valM.getValueProduced();
    }
    
    if (regNum == M.dstE.get() && M.cnd.get() == 1)
    {
      return M.valE.get();
    }
    
    // Forwarding from W to D.
    if (regNum == W.dstM.get())
    {
      return W.valM.get();
    }
    
    if (regNum == W.dstE.get() && W.cnd.get() == 1)
    {
      return W.valE.get();
    }
    
    return reg.get (regNum);
  }
  
  /**
   * The DECODE stage of CPU
   * @throws Register.TimingException
   */
  @Override protected void decode () throws Register.TimingException {
    
    // pass-through signals
    d.stat.set (D.stat.get());
    d.iCd.set  (D.iCd.get());
    d.iFn.set  (D.iFn.get());
    d.valC.set (D.valC.get());
    d.valP.set (D.valP.get());
    
    if (D.stat.get() == S_AOK) {
      try {
        
        // srcA MUX
        switch (D.iCd.get()) {
          case I_RRMVXX:
          case I_RMMOVL:
          case I_OPL:
          case I_PUSHL:
            d.srcA.set (D.rA.get());
            break;
          case I_CALL:
            d.srcA.set(D.iFn.get() == X_INDIRECT_CALL ? D.rA.get() : R_NONE);
            break;
          case I_RET:
          case I_POPL:
          case I_LEAVE:
            d.srcA.set (R_ESP);
            break;
          default:
            d.srcA.set (R_NONE);
        }
        
        // srcB MUX
        switch (D.iCd.get()) {
          case I_RMMOVL:
          case I_MRMOVL:
          case I_OPL:
          case I_IOPL:
          case I_JMPI:
            d.srcB.set (D.rB.get());
            break;
          case I_RET:
          case I_PUSHL:
          case I_POPL:
          case I_LEAVE:
            d.srcB.set (R_ESP);
            break;
          case I_CALL:
            d.srcB.set(isCallUsingReg(D.iFn.get()) ? D.rB.get() : R_ESP);
            break;
          default:
            d.srcB.set (R_NONE);
        }
        
        // dstE MUX
        switch (D.iCd.get()) {
          case I_RRMVXX:
          case I_IRMOVL:
          case I_OPL:
          case I_IOPL:
            d.dstE.set (D.rB.get());
            break;
          case I_RET:
          case I_PUSHL:
          case I_POPL:
          case I_LEAVE:
            d.dstE.set (R_ESP);
            break;
          case I_CALL:
            d.dstE.set(isCallUsingReg(D.iFn.get()) ? D.rA.get() : R_ESP);
            break;
          default:
            d.dstE.set (R_NONE);
        }
        
        // dstM MUX
        switch (D.iCd.get()) {
          case I_MRMOVL:
          case I_POPL:
            d.dstM.set (D.rA.get());
            break;
          case I_LEAVE:
            d.dstM.set (R_EBP);
            break;
          default:
            d.dstM.set (R_NONE);
        }
        
        try
        {
          d.valA.set(decode_ReadRegisterWithForwarding(d.srcA.getValueProduced()));
          d.valB.set(decode_ReadRegisterWithForwarding(d.srcB.getValueProduced()));
        }
        catch (RegisterSet.InvalidRegisterNumberException irne)
        {
          throw new InvalidInstructionException (irne);
        }
        
      } catch (InvalidInstructionException iie) {
        d.stat.set (S_INS);
      }
    }
    
    if (d.stat.getValueProduced()!=S_AOK) {
      d.srcA.set (R_NONE);
      d.srcB.set (R_NONE);
      d.dstE.set (R_NONE);
      d.dstM.set (R_NONE);
    }
  }
  
  /**
   * The EXECUTE stage of CPU
   * @throws Register.TimingException
   */
  
  @Override protected void execute () throws Register.TimingException {
    
    // pass-through signals
    e.stat.set (E.stat.get());
    e.iCd.set  (E.iCd.get());
    e.iFn.set  (E.iFn.get());
    e.valC.set (E.valC.get());
    e.valA.set (E.valA.get());
    e.dstE.set (E.dstE.get());
    e.dstM.set (E.dstM.get());
    e.valP.set (E.valP.get());
    
    if (E.stat.get()==S_AOK) {
      
      // aluA MUX
      int aluA;
      switch (E.iCd.get()) {
        case I_RRMVXX:
        case I_OPL:
          aluA = E.valA.get();
          break;
        case I_IOPL:
        case I_IRMOVL:
        case I_MRMOVL:
        case I_RMMOVL:
        case I_JMPI:
          aluA = E.valC.get();
          break;
        case I_RET:
        case I_POPL:
          aluA = 4;
          break;
        case I_CALL:
          if (!isCallUsingReg(E.iFn.get()))
          {
            aluA = -4;
          }
          else if (E.iFn.get() == X_INDIRECT_CALL)
          {
            aluA = 0;
          }
          else
          {
            aluA = E.valC.get();
          }
          break;
        case I_PUSHL:
          aluA = -4;
          break;
        default:
          aluA = 0;
      }
      
      // aluB MUX
      int aluB;
      switch (E.iCd.get()) {
        case I_RRMVXX:
        case I_IRMOVL:
          aluB = 0;
          break;
        case I_RMMOVL:
        case I_MRMOVL:
        case I_CALL:
        case I_OPL:
        case I_IOPL:
        case I_RET:
        case I_PUSHL:
        case I_POPL:
        case I_JMPI:
          aluB = E.valB.get();
          break;
        default:
          aluB = 0;
      }
      
      // aluFun and setCC muxes MUX
      int     aluFun;
      boolean setCC;
      switch (E.iCd.get()) {
        case I_RRMVXX:
        case I_IRMOVL:
        case I_RET:
        case I_PUSHL:
        case I_POPL:
          aluFun = A_ADDL;
          setCC = false;
          break;
        case I_CALL:
        case I_JMPI:
        case I_RMMOVL:
        case I_MRMOVL:
          setCC = false;
          switch (E.iFn.get() & X_SCALE_MASK) {
            case 0x0:
            case 0x1:
              aluFun = A_ADDL;
              break;
            case 0x2:
              aluFun = A_ADDL_LSHIFT_1;
              break;
            case 0x4:
              aluFun = A_ADDL_LSHIFT_2;
              break;
            default:
              aluFun = 0;
          }
          break;
        case I_OPL:
        case I_IOPL:
          aluFun = E.iFn.get();
          setCC  = true;
          break;
        default:
          aluFun = 0;
          setCC  = false;
      }
      
      // the ALU
      boolean overflow;
      switch (aluFun) {
        case A_ADDL:
          e.valE.set (aluB + aluA);
          overflow = ((aluB < 0) == (aluA < 0)) && ((e.valE.getValueProduced() < 0) != (aluB < 0));
          break;
        case A_SUBL:
          e.valE.set (aluB - aluA);
          overflow = ((aluB < 0) != (aluA < 0)) && ((e.valE.getValueProduced() < 0) != (aluB < 0));
          break;
        case A_ANDL:
          e.valE.set (aluB & aluA);
          overflow = false;
          break;
        case A_XORL:
          e.valE.set (aluB ^ aluA);
          overflow = false;
          break;
        case A_MULL:
          int result = aluB * aluA;
          e.valE.set (result);
          overflow = aluB != 0 && result / aluB != aluA;
          break;
        case A_DIVL:
          e.valE.set (aluA == 0 ? aluB : aluB / aluA);
          overflow = aluA == 0;
          break;
        case A_MODL:
          e.valE.set (aluA == 0 ? aluB : aluB % aluA);
          overflow = aluA == 0;
          break;
        case A_ADDL_LSHIFT_1:
          e.valE.set ((aluB << 1) + aluA);
          overflow = ((aluB < 0) == (aluA < 0)) && ((e.valE.getValueProduced() < 0) != (aluB < 0));
          break;
        case A_ADDL_LSHIFT_2:
          e.valE.set ((aluB << 2) + aluA);
          overflow = ((aluB < 0) == (aluA < 0)) && ((e.valE.getValueProduced() < 0) != (aluB < 0));
          break;
        default:
          overflow = false;
      }
      
      // CC MUX
      if (setCC)
        p.cc.set (((e.valE.getValueProduced() == 0)? 0x100 : 0) | ((e.valE.getValueProduced() < 0)? 0x10 : 0) | (overflow? 0x1 : 0));
      else
        p.cc.set (P.cc.get());
      
      // cnd MUX
      boolean cnd;
      switch (E.iCd.get()) {
        case I_JXX:
        case I_RRMVXX:
          boolean zf = (P.cc.get() & 0x100) != 0;
          boolean sf = (P.cc.get() & 0x010) != 0;
          boolean of = (P.cc.get() & 0x001) != 0;
          switch (E.iFn.get()) {
            case C_NC:
              cnd = true;
              break;
            case C_LE:
              cnd = (sf ^ of) | zf;
              break;
            case C_L:
              cnd = sf ^ of;
              break;
            case C_E:
              cnd = zf;
              break;
            case C_NE:
              cnd = ! zf;
              break;
            case C_GE:
              cnd = ! (sf ^ of);
              break;
            case C_G:
              cnd = ! (sf ^ of) & ! zf;
              break;
            default:
              throw new AssertionError();
          }
          break;
        default:
          cnd = true;
      }
      e.cnd.set (cnd? 1 : 0);
      
    } else
      e.cnd.set (0);
  }
  
  /**
   * The MEMORY stage of CPU
   * @throws Register.TimingException
   */
  
  @Override protected void memory () throws Register.TimingException {
    
    // pass-through signals
    m.iCd.set  (M.iCd.get());
    m.iFn.set  (M.iFn.get());
    m.cnd.set  (M.cnd.get());
    m.valE.set (M.valE.get());
    m.dstE.set (M.dstE.get());
    m.dstM.set (M.dstM.get());
    m.valP.set (M.valP.get());
    
    if (M.stat.get()==S_AOK) {
      try {
        
        // write Main Memory
        switch (M.iCd.get()) {
          case I_RMMOVL:
          case I_PUSHL:
            mem.writeInteger (M.valE.get(), M.valA.get());
            break;
          case I_CALL:
            if (!isCallUsingReg(M.iFn.get()))
            {
              mem.writeInteger (M.valE.get(), M.valP.get());
            }
            break;
          default:
        }
        
        // valM MUX (read main memory)
        switch (M.iCd.get()) {
          case I_MRMOVL:
            m.valM.set (mem.readInteger (M.valE.get()));
            break;
          case I_JMPI:
            switch (M.iFn.get() & X_INDIRECT_MASK) {
              case X_INDIRECT_FLAG:
                m.valM.set (M.valE.get());
                break;
              case X_DBL_INDIRECT_FLAG:
                m.valM.set (mem.readInteger (M.valE.get()));
                break;
            }
            break;
          case I_RET:
          case I_POPL:
          case I_LEAVE:
            m.valM.set (mem.readInteger (M.valA.get()));
            break;
          case I_CALL:
            if (isDirectCall(M.iFn.get())) {
              mem.writeInteger(M.valE.get(), M.valP.get());
            }
            else if (isIndirectCallUsingStack(M.iFn.get())) {
              m.valM.set (M.valA.get());
            }
            else if (isCallUsingReg(M.iFn.get()))
            {
              m.valE.set(M.valP.get());
              m.valM.set (isIndirectCallUsingReg(M.iFn.get()) ? M.valE.get() : mem.readInteger (M.valE.get()));
            }
            break;
          default:
        }
        m.stat.set (M.stat.get());
        
      } catch (AbstractMainMemory.InvalidAddressException iae) {
        m.stat.set (S_ADR);
      }
      
    } else {
      m.stat.set (M.stat.get());
    }
  }
  
  /**
   * The WRITE BACK stage of CPU
   * @throws MachineHaltException                       if instruction halts the CPU (e.g., halt instruction).
   * @throws InvalidInstructionException
   * @throws AbstractMainMemory.InvalidAddressException
   * @throws Register.TimingException
   */
  
  @Override protected void writeBack () throws MachineHaltException, InvalidInstructionException, AbstractMainMemory.InvalidAddressException, Register.TimingException {
    if (W.stat.get()==S_AOK)
      try {
        try {
          // write valE to register file
          if (W.dstE.get()!=R_NONE && W.cnd.get()==1)
            reg.set (W.dstE.get(), W.valE.get());
          
          // write valM to register file
          if (W.dstM.get()!=R_NONE)
            reg.set (W.dstM.get(), W.valM.get());
          
          w.stat.set (W.stat.get());
          
        } catch (RegisterSet.InvalidRegisterNumberException irne) {
          throw new InvalidInstructionException (irne);
        }
        
      } catch (InvalidInstructionException iie) {
        w.stat.set (S_INS);
      }
    else
      w.stat.set (W.stat.get());
    
    if (w.stat.getValueProduced()==S_ADR)
      throw new AbstractMainMemory.InvalidAddressException();
    else if (w.stat.getValueProduced()==S_INS)
      throw new InvalidInstructionException();
    else if (w.stat.getValueProduced()==S_HLT)
      throw new MachineHaltException();
  }
}
