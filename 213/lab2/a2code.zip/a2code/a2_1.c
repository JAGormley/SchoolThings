int b;
int c;
int a[10];

b = 3;
c = b + 5; 
a[5] = 5;
a[3] = a[3] + 5;
a[b] = a[3] + b + a[b & 7];

