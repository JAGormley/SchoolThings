int a[5];
int b[5];
int i;
int *d = (int *) malloc(8* sizeof(int));

a[i] = b[i+1] + b[i+2];
d{i} = a[i] + b[i]
d[i] = a[b[i]] + b[a[i]];
d[a[i]] = a[b[i & 3] & 3] + b[a[i & 3] & 3] - d[i];
