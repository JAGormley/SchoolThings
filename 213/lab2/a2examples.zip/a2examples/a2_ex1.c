int a;
int b;
int c[4];

b = a + 5;
c[0] = ~(a + c[b]);
